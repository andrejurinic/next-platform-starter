import { Check, X } from "lucide-react"

export default function ComparisonTable() {
  return (
    <div className="w-full overflow-auto">
      <table className="w-full border-collapse min-w-[600px]">
        <thead>
          <tr className="bg-muted/50">
            <th className="border p-3 text-left font-medium">Opção</th>
            <th className="border p-3 text-center font-medium">Responde leads 24/7</th>
            <th className="border p-3 text-center font-medium">Atendimento Humanizado</th>
            <th className="border p-3 text-center font-medium">Agenda Consultas</th>
            <th className="border p-3 text-center font-medium">Custo Acessível</th>
            <th className="border p-3 text-center font-medium">Fácil de Usar</th>
          </tr>
        </thead>
        <tbody>
          <tr className="bg-primary/5 border-primary">
            <td className="border p-3 font-medium">PsiBot</td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-primary mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-xs text-muted-foreground mt-1">99% não percebem que é um bot</span>
              </div>
            </td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-primary mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-xs text-muted-foreground mt-1">R$ 197/mês</span>
              </div>
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <Check className="h-5 w-5 text-primary" />
                <span className="text-xs text-muted-foreground mt-1">Sem precisar programar</span>
              </div>
            </td>
          </tr>
          <tr>
            <td className="border p-3 font-medium">Secretária Remota</td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-muted-foreground mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-muted-foreground mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-muted-foreground mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <X className="h-5 w-5 text-red-500" />
                <span className="text-xs text-muted-foreground mt-1">Custa R$ 800+ por mês</span>
              </div>
            </td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-muted-foreground mx-auto" />
            </td>
          </tr>
          <tr>
            <td className="border p-3 font-medium">Softwares Genéricos</td>
            <td className="border p-3 text-center">
              <Check className="h-5 w-5 text-muted-foreground mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <X className="h-5 w-5 text-red-500" />
                <span className="text-xs text-muted-foreground mt-1">Respostas frias e robóticas</span>
              </div>
            </td>
            <td className="border p-3 text-center">
              <X className="h-5 w-5 text-red-500 mx-auto" />
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <X className="h-5 w-5 text-red-500" />
                <span className="text-xs text-muted-foreground mt-1">Planos caros para grandes clínicas</span>
              </div>
            </td>
            <td className="border p-3 text-center">
              <div className="flex flex-col items-center">
                <X className="h-5 w-5 text-red-500" />
                <span className="text-xs text-muted-foreground mt-1">Configuração complexa</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

