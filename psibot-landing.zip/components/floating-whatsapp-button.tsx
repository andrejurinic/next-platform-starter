import { MessageCircle } from "lucide-react"

export default function FloatingWhatsAppButton() {
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <button
        className="bg-primary text-white rounded-full p-4 shadow-lg hover:bg-primary/90 transition-all duration-300 hover:scale-110 flex items-center gap-2"
        aria-label="Fale conosco pelo WhatsApp"
      >
        <MessageCircle className="h-6 w-6" />
        <span className="hidden md:inline">Testar o PsiBot</span>
      </button>
    </div>
  )
}

