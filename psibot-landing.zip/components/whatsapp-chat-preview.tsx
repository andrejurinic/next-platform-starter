"use client"

import { useState } from "react"
import { MessageCircle, Smile, Paperclip, Mic, Check } from "lucide-react"

export default function WhatsAppChatPreview() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Olá! Sou o PsiBot, assistente virtual da Dra. Ana Silva. Como posso ajudar?",
      isBot: true,
      time: "14:30",
    },
    {
      id: 2,
      text: "Olá, gostaria de marcar uma consulta para esta semana.",
      isBot: false,
      time: "14:31",
    },
    {
      id: 3,
      text: "Claro! A Dra. Ana tem os seguintes horários disponíveis esta semana:",
      isBot: true,
      time: "14:31",
    },
    {
      id: 4,
      text: "• Quarta-feira, 15h00\n• Quinta-feira, 10h00\n• Sexta-feira, 16h30",
      isBot: true,
      time: "14:31",
    },
  ])

  return (
    <div className="w-full max-w-[320px] rounded-xl overflow-hidden shadow-lg border">
      {/* Header */}
      <div className="bg-secondary p-3 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
          <MessageCircle className="h-6 w-6 text-secondary" />
        </div>
        <div className="text-white">
          <p className="font-medium">Dra. Ana Silva</p>
          <p className="text-xs opacity-80">Online</p>
        </div>
      </div>

      {/* Chat body */}
      <div className="bg-[#E5DDD5] h-[300px] p-3 flex flex-col gap-2 overflow-y-auto">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`max-w-[80%] p-2 rounded-lg relative ${
              message.isBot ? "bg-white self-start rounded-tl-none" : "bg-accent self-end rounded-tr-none"
            }`}
          >
            <p className="text-sm">{message.text}</p>
            <p className="text-[10px] text-gray-500 text-right mt-1">
              {message.time}
              {!message.isBot && <Check className="h-3 w-3 inline ml-1 text-primary" />}
            </p>
          </div>
        ))}
      </div>

      {/* Input area */}
      <div className="bg-[#F0F0F0] p-2 flex items-center gap-2">
        <div className="flex items-center gap-2">
          <button className="text-gray-500">
            <Smile className="h-5 w-5" />
          </button>
          <button className="text-gray-500">
            <Paperclip className="h-5 w-5" />
          </button>
        </div>
        <input
          type="text"
          placeholder="Digite uma mensagem"
          className="flex-1 bg-white rounded-full py-2 px-3 text-sm focus:outline-none"
        />
        <button className="bg-primary rounded-full p-2 text-white">
          <Mic className="h-5 w-5" />
        </button>
      </div>
    </div>
  )
}

