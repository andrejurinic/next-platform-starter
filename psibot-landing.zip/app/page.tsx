"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, MessageCircle, Shield, Clock, Users, BarChart, Menu, X, Check } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import WhatsAppChatPreview from "@/components/whatsapp-chat-preview"
import FloatingWhatsAppButton from "@/components/floating-whatsapp-button"
import ComparisonTable from "@/components/comparison-table"
import { useState } from "react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main>
        <HeroSection />
        <ProblemSolutionSection />
        <LiveDemoSection />
        <BenefitsSection />
        <TestimonialsSection />
        <ComparisonSection />
        <PricingSection />
        <FaqSection />
        <CtaSection />
      </main>
      <Footer />
      <FloatingWhatsAppButton />
    </div>
  )
}

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">PsiBot</span>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="#features" className="text-sm font-medium hover:text-primary">
            Recursos
          </Link>
          <Link href="#how-it-works" className="text-sm font-medium hover:text-primary">
            Como Funciona
          </Link>
          <Link href="#pricing" className="text-sm font-medium hover:text-primary">
            Preços
          </Link>
          <Link href="#faq" className="text-sm font-medium hover:text-primary">
            FAQ
          </Link>
          <Link href="#contact" className="text-sm font-medium hover:text-primary">
            Contato
          </Link>
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="outline" size="sm">
            Entrar
          </Button>
          <Button size="sm">Começar Grátis</Button>
        </div>

        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="md:hidden container py-4 bg-background">
          <nav className="flex flex-col gap-4">
            <Link href="#features" className="text-sm font-medium hover:text-primary">
              Recursos
            </Link>
            <Link href="#how-it-works" className="text-sm font-medium hover:text-primary">
              Como Funciona
            </Link>
            <Link href="#pricing" className="text-sm font-medium hover:text-primary">
              Preços
            </Link>
            <Link href="#faq" className="text-sm font-medium hover:text-primary">
              FAQ
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-primary">
              Contato
            </Link>
            <div className="flex flex-col gap-2 pt-2">
              <Button variant="outline" size="sm">
                Entrar
              </Button>
              <Button size="sm">Começar Grátis</Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}

function HeroSection() {
  return (
    <section className="py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-accent/30">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Seu ChatGPT para WhatsApp: Atendimento Inteligente e Humanizado para Psicólogos
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Liberte-se do WhatsApp! O PsiBot responde seus leads automaticamente, agenda consultas e garante um
                atendimento humanizado 24/7 – tudo sem parecer um robô.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" className="px-8">
                Quero um atendimento inteligente no WhatsApp
              </Button>
              <Button variant="outline" size="lg" className="px-8">
                Ver demonstração
              </Button>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <CheckCircle className="h-4 w-4 text-primary" />
                <span>14 dias grátis</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="h-4 w-4 text-primary" />
                <span>Sem cartão</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="h-4 w-4 text-primary" />
                <span>Cancelamento fácil</span>
              </div>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[500px] flex items-center justify-center">
              <div className="transform rotate-3 scale-90 md:scale-100">
                <WhatsAppChatPreview />
              </div>
              <div className="absolute -left-4 -bottom-4 transform -rotate-3 scale-90 md:scale-100 z-10 hidden md:block">
                <WhatsAppChatPreview />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function ProblemSolutionSection() {
  return (
    <section id="problem-solution" className="py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Problema */}
          <div className="space-y-6">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl md:text-4xl">O Problema</h2>
              <p className="text-muted-foreground">
                Se você é psicólogo autônomo ou tem uma pequena clínica, provavelmente já passou por isso:
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <XCircle className="h-6 w-6 text-red-500 shrink-0 mt-0.5" />
                <p>Precisa responder mensagens o dia todo e perde tempo que poderia estar usando para atender.</p>
              </div>
              <div className="flex items-start gap-3">
                <XCircle className="h-6 w-6 text-red-500 shrink-0 mt-0.5" />
                <p>Já tentou automações simples ou mensagens automáticas no WhatsApp, mas elas afastaram os leads.</p>
              </div>
              <div className="flex items-start gap-3">
                <XCircle className="h-6 w-6 text-red-500 shrink-0 mt-0.5" />
                <p>Considerou contratar uma secretária remota, mas o custo é alto.</p>
              </div>
            </div>
            <div className="relative h-64 md:h-80 rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Psicólogo estressado com muitas mensagens no WhatsApp"
                fill
                className="object-cover"
              />
            </div>
          </div>

          {/* Solução */}
          <div className="space-y-6">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl md:text-4xl">A Solução</h2>
              <p className="text-muted-foreground">O PsiBot resolve tudo isso de forma inteligente:</p>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                <p>Responde leads de forma natural e humanizada, sem parecer um robô.</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                <p>Agenda consultas automaticamente, sem você precisar intervir.</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                <p>Funciona 24 horas por dia, garantindo que ninguém fique sem resposta.</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
                <p>Custa menos do que uma única sessão mensalmente.</p>
              </div>
            </div>
            <div className="relative h-64 md:h-80 rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Psicólogo atendendo paciente tranquilamente enquanto o PsiBot cuida das mensagens"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function LiveDemoSection() {
  return (
    <section id="live-demo" className="py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="space-y-2 max-w-3xl">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Quer ver o PsiBot funcionando AO VIVO?
            </h2>
            <p className="text-muted-foreground md:text-xl">
              Mande uma mensagem para <span className="font-bold">+55 11 99999-9999</span> e veja como ele atende de
              forma natural!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-12 w-full max-w-5xl">
            <div className="flex flex-col items-center space-y-3 p-6 border rounded-lg bg-background shadow-sm">
              <MessageCircle className="h-10 w-10 text-primary" />
              <h3 className="text-xl font-bold">Teste como ele interage com leads</h3>
              <p className="text-muted-foreground text-center">
                Experimente fazer perguntas sobre consultas e veja como o PsiBot responde naturalmente.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-3 p-6 border rounded-lg bg-background shadow-sm">
              <Clock className="h-10 w-10 text-primary" />
              <h3 className="text-xl font-bold">Veja como ele agenda consultas</h3>
              <p className="text-muted-foreground text-center">
                Tente agendar uma consulta e observe como o processo é simples e automático.
              </p>
            </div>

            <div className="flex flex-col items-center space-y-3 p-6 border rounded-lg bg-background shadow-sm">
              <Shield className="h-10 w-10 text-primary" />
              <h3 className="text-xl font-bold">Experimente sem compromisso</h3>
              <p className="text-muted-foreground text-center">
                Teste todas as funcionalidades sem precisar se cadastrar ou pagar nada.
              </p>
            </div>
          </div>

          <div className="mt-12">
            <Button size="lg" className="px-8">
              Testar Agora o PsiBot
            </Button>
          </div>

          <div className="mt-12 flex items-center justify-center">
            <div className="relative w-full max-w-[320px]">
              <WhatsAppChatPreview />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function BenefitsSection() {
  const benefits = [
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: "Economia de Tempo",
      description: "Você foca nos atendimentos enquanto o PsiBot cuida dos leads.",
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-primary" />,
      title: "Atendimento Humanizado",
      description: "99% das pessoas não percebem que é um bot.",
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Funciona 24/7",
      description: "Nunca mais perca um paciente por falta de resposta.",
    },
    {
      icon: <Check className="h-8 w-8 text-primary" />,
      title: "Zero Complexidade",
      description: "Não precisa programar nada, basta ativar e usar.",
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-primary" />,
      title: "Mensagens Precisas",
      description: "Nada de informações erradas ou confusas.",
    },
    {
      icon: <BarChart className="h-8 w-8 text-primary" />,
      title: "Conversão Maior",
      description: "Leads respondidos rapidamente têm mais chance de se tornarem pacientes.",
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Custo-Benefício",
      description: "Menos que uma sessão mensalmente, sem precisar pagar uma secretária.",
    },
  ]

  return (
    <section id="features" className="py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Benefícios do PsiBot</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Transforme seu atendimento e economize tempo com nosso assistente virtual inteligente.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
              <div className="p-2 rounded-full bg-primary/10">{benefit.icon}</div>
              <h3 className="text-xl font-bold">{benefit.title}</h3>
              <p className="text-center text-muted-foreground">{benefit.description}</p>
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-12">
          <Button size="lg" className="px-8">
            Quero um Atendimento Inteligente no WhatsApp
          </Button>
        </div>
      </div>
    </section>
  )
}

function TestimonialsSection() {
  const testimonials = [
    {
      quote:
        "Antes do PsiBot, eu perdia muito tempo respondendo mensagens no WhatsApp. Agora, tudo funciona sozinho, meus pacientes recebem respostas rápidas e naturais, e eu foco no que realmente importa: os atendimentos!",
      author: "Juliana M.",
      role: "Psicóloga Clínica",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "Testei várias automações, mas todas pareciam robóticas. O PsiBot é diferente! Meus leads conversam com ele como se fosse um humano. A conversão de novos pacientes aumentou muito!",
      author: "Rafael T.",
      role: "Psicólogo Infantil",
      avatar: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "O PsiBot revolucionou minha clínica. Reduzi em 70% o tempo gasto com agendamentos e consigo focar mais nos atendimentos. Meus pacientes adoram a rapidez nas respostas!",
      author: "Mariana S.",
      role: "Psicóloga e Professora",
      avatar: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              O que psicólogos estão dizendo sobre o PsiBot
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Profissionais de todo o Brasil já transformaram seus atendimentos com o PsiBot.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 mt-12">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="flex flex-col justify-between space-y-4 rounded-lg border p-6 shadow-sm bg-background"
            >
              <div>
                <p className="text-muted-foreground italic">"{testimonial.quote}"</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden">
                  <Image
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.author}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <p className="font-bold">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <p className="text-lg font-medium mb-6">Ainda não acredita?</p>
          <p className="text-muted-foreground mb-8">
            Mande uma mensagem para <span className="font-bold">+55 11 99999-9999</span> e veja o PsiBot funcionando!
          </p>
          <Button size="lg" className="px-8">
            Testar Agora o PsiBot
          </Button>
        </div>
      </div>
    </section>
  )
}

function ComparisonSection() {
  return (
    <section className="py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Por que o PsiBot é a melhor opção?
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Compare e veja por que tantos psicólogos estão escolhendo o PsiBot.
            </p>
          </div>
        </div>

        <div className="mt-12 overflow-x-auto">
          <ComparisonTable />
        </div>

        <div className="mt-12 max-w-3xl mx-auto space-y-6">
          <h3 className="text-xl font-bold text-center">PsiBot tem o melhor custo-benefício:</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <p>Sem pagar caro por uma secretária.</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <p>Sem usar automações burras que afastam pacientes.</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="h-6 w-6 text-primary shrink-0 mt-0.5" />
              <p>Sem precisar configurar nada complicado.</p>
            </div>
          </div>
        </div>

        <div className="flex justify-center mt-12">
          <Button size="lg" className="px-8">
            Quero um Atendimento Inteligente no WhatsApp
          </Button>
        </div>
      </div>
    </section>
  )
}

function PricingSection() {
  return (
    <section id="pricing" className="py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-block rounded-full bg-primary-foreground px-3 py-1 text-sm font-medium text-primary mb-4">
              🔥 Oferta Especial – Versão Beta (Vagas Limitadas!)
            </div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              PsiBot – Seu ChatGPT para WhatsApp
            </h2>
            <p className="text-primary-foreground/80 md:text-xl">
              Atendimento inteligente e humanizado por menos do que uma única sessão mensal!
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-3xl mt-12 bg-background text-foreground rounded-xl overflow-hidden shadow-xl">
          <div className="p-8 space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-baseline">
                <h3 className="text-2xl font-bold">Plano Completo</h3>
                <div className="flex items-baseline">
                  <span className="text-4xl font-bold">R$ 197</span>
                  <span className="text-sm text-muted-foreground">/mês</span>
                </div>
              </div>
              <p className="text-muted-foreground">
                Tudo o que você precisa para automatizar seu atendimento no WhatsApp
              </p>
            </div>

            <div className="space-y-4 pt-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Atendimento inteligente e humanizado</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Agendamento automático de consultas</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Respostas precisas e naturais</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Funciona 24/7 sem precisar de você</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Integração com seu calendário</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p>Suporte técnico prioritário</p>
              </div>
            </div>

            <div className="pt-6">
              <Button className="w-full py-6 text-lg" size="lg">
                Quero um Atendimento Inteligente no WhatsApp
              </Button>
            </div>

            <div className="pt-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Shield className="h-5 w-5 text-primary" />
                <p className="font-medium">Garantia 100% sem risco</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Teste por 30 dias. Se não gostar, devolvemos seu dinheiro!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function FaqSection() {
  const faqs = [
    {
      question: "O PsiBot precisa de configuração complicada?",
      answer: "Não! Ele já vem pronto para uso. Basta ativar e deixar que ele trabalhe para você.",
    },
    {
      question: "O atendimento não vai parecer muito robótico?",
      answer:
        "Não! O PsiBot usa inteligência artificial avançada (ChatGPT) e 99% das pessoas não percebem que estão falando com um bot.",
    },
    {
      question: "Ele agenda consultas sozinho?",
      answer: "Sim! Ele pode agendar automaticamente no WhatsApp, sem você precisar intervir.",
    },
    {
      question: "Quanto custa?",
      answer: "Apenas R$ 197/mês, menos do que o valor de uma única sessão mensalmente.",
    },
    {
      question: "E se eu não gostar?",
      answer: "Sem problema! Você tem 30 dias de garantia. Se não ficar satisfeito, devolvemos seu dinheiro.",
    },
    {
      question: "Posso testar antes de contratar?",
      answer: "Sim! Mande uma mensagem para +55 11 99999-9999 e veja o PsiBot funcionando ao vivo!",
    },
    {
      question: "Como o PsiBot se integra ao meu WhatsApp?",
      answer:
        "A integração é simples e segura. Você só precisa escanear um QR Code com seu WhatsApp Business e nossa plataforma se conecta automaticamente, sem necessidade de instalação de aplicativos adicionais.",
    },
    {
      question: "O PsiBot atende às normas do Conselho Federal de Psicologia?",
      answer:
        "Sim, desenvolvemos o PsiBot seguindo todas as diretrizes éticas e de privacidade estabelecidas pelo CFP. Todas as conversas são criptografadas e os dados dos pacientes são tratados com o máximo de segurança.",
    },
  ]

  return (
    <section id="faq" className="py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Perguntas Frequentes</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Tire suas dúvidas sobre o PsiBot e como ele pode ajudar na sua prática clínica.
            </p>
          </div>
        </div>
        <div className="mx-auto max-w-3xl mt-12">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left font-medium">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}

function CtaSection() {
  return (
    <section id="contact" className="py-12 md:py-24 lg:py-32 bg-accent/30">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Pronto para transformar seu atendimento?
              </h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Junte-se a centenas de psicólogos que já otimizaram suas clínicas com o PsiBot. Comece seu teste
                gratuito hoje mesmo.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" className="px-8">
                Quero um Atendimento Inteligente no WhatsApp
              </Button>
              <Button variant="outline" size="lg" className="px-8">
                Testar Agora o PsiBot
              </Button>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[500px] flex items-center justify-center">
              <WhatsAppChatPreview />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <div className="grid gap-8 lg:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <MessageCircle className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">PsiBot</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Transformando o atendimento psicológico com tecnologia e humanização.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                  <rect x="2" y="9" width="4" height="12"></rect>
                  <circle cx="4" cy="4" r="2"></circle>
                </svg>
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Produto</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#features" className="text-muted-foreground hover:text-foreground">
                  Recursos
                </Link>
              </li>
              <li>
                <Link href="#pricing" className="text-muted-foreground hover:text-foreground">
                  Preços
                </Link>
              </li>
              <li>
                <Link href="#faq" className="text-muted-foreground hover:text-foreground">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Empresa</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Sobre nós
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Carreiras
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Imprensa
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Termos de Uso
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Privacidade
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Cookies
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Licenças
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} PsiBot. Todos os direitos reservados.
          </p>
          <p className="text-xs text-muted-foreground mt-4 md:mt-0">Feito com ❤️ para psicólogos de todo o Brasil</p>
        </div>
      </div>
    </footer>
  )
}

